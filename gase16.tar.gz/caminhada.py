#!/usr/bin/env python3
# -- coding: utf-8 --

import sys
import argparse
from timeit import default_timer as timer

from datastruct.graph import Graph


parser = argparse.ArgumentParser(
    description='Resolve problema do caminho cíclico maximal em um grafo ponderado lido durante a execução do programa.'
)
parser.add_argument('-d', '--debug', action='store_true', dest='debug', help='faz o programa imprimir na saída de erro o caminho atual e o conjunto C_l computado')
parser.add_argument('-p', '--plot', action='store_true', dest='plot', help='faz o programa imprimir na saída de erro a matriz de adjacência do grafo passado como entrada, se o sistema tiver networkx e matplotlib instalados uma imagem do grafo é gerada')
parser.add_argument('--backtrack', action='store_true', dest='useBacktrack', help='faz o programa usar backtracking em vez de branch and bound')

args = parser.parse_args()


################ BACKTRACK ##############
def backtrackBound(path):
    return float('inf')

# def backtrackBound(path):
#     global g
#     b = g.weight(path)
#     for i in range(n_verts):
#         for j in range(i):
#                 b += g._weight(i, j)
#     return b

def backTrack(l):
    global X
    global OptX
    global g
    global numberOfNodesExplored
    global args

    CurX = X[0:l]
    numberOfNodesExplored += 1
    if args.debug:
        sys.stderr.write('CurX: ' + str(CurX) + '\n')

    if len(CurX) > 2 and CurX[0].id == CurX[l-1].id:
        if g.weight(CurX) > g.weight(OptX):
            OptX = CurX
    
    C_l = [j for j in g.vertices if j not in CurX[1:] and g._weight(CurX[l-1].id, j.id) != 0]
    if args.debug:
        sys.stderr.write('C_l: ' + str(C_l) + '\n')

    if args.debug:
        sys.stderr.write('\n')
    B = backtrackBound(CurX)
    for x_i in C_l:
        if (l+1 < len(g.vertices) or x_i == CurX[0]) and B > g.weight(OptX):
            X[l] = x_i
            backTrack(l+1)


################ BRANCH AND BOUND ##############
def computeC_l(CurX, graph):
    if len(CurX) > 1 and CurX[-1] == CurX[0]:
        return []

    subgraph_vertices = []
    for v in graph.vertices:
        if v not in CurX[1:]:
            subgraph_vertices.append(v)
    Graph.setConnectedComponents(graph, subgraph_vertices)

    return [j for j in graph.vertices if j not in CurX[1:] and graph._weight(CurX[-1].id, j.id) != 0 and j.component == CurX[0].component]

def bound(path):
    global g

    b = g.weight(path)

    if path[0] == path[-1]:
        return b

    for idx, v in enumerate(g.vertices):
        for j in range(idx):
            if v not in path[1:]:
                if path[0].component == v.component:
                    b += g._weight(j, idx)
    return b

def branchAndBound(l):
    global X
    global OptX
    global g
    global numberOfNodesExplored
    global args

    CurX = X[0:l]
    numberOfNodesExplored += 1
    if args.debug:
        sys.stderr.write('CurX: ' + str(CurX) + '\n')
    
    if len(CurX) > 2 and CurX[0].id == CurX[l-1].id:
        if g.weight(CurX) > g.weight(OptX):
            OptX = CurX
    
    C_l = computeC_l(CurX, g)
    if args.debug:
        sys.stderr.write('C_l: ' + str(C_l) + '\n')

    next_choice = []
    next_bound = []
    for x in C_l:
        X[l] = x
        next_choice.append(x)
        next_bound.append(bound(X[0:l+1]))
 
    next_choices_and_bounds = list(zip(next_choice, next_bound))
    next_choices_and_bounds.sort(key=lambda x : x[1], reverse=True)

    if args.debug:
        sys.stderr.write('\n')
    for choice, B in next_choices_and_bounds:
        if (l+1 < len(g.vertices) or choice == CurX[0]) and B > g.weight(OptX):
            X[l] = choice
            branchAndBound(l+1)


if __name__ == '__main__':
    start = timer()

    n_verts = int(sys.stdin.readline())
    upper_half_matrix = [list(map(int, sys.stdin.readline().split(' '))) for i in range(n_verts-1)] 

    g = Graph(n_verts)
    g.addUpperHalfAdjacencyMatrix(upper_half_matrix)
    if args.plot:
        g.plot()

    X = g.vertices[:]
    OptX = []
    numberOfNodesExplored = 0

    if args.useBacktrack:
        backTrack(1)
    else:
        branchAndBound(1)

    end = timer() 
    sys.stderr.write('\t ' + str(end - start) + ' seconds elapsed\n')
    sys.stderr.write('\t ' + str(numberOfNodesExplored) + ' possible solutions analised\n')
    
    print(g.weight(OptX))
    print(*[v.id+1 for v in OptX])
