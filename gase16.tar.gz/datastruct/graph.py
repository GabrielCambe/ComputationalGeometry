try:
    import networkx as nx 
    import matplotlib.pyplot as plt 
    importedVisLibs = True
except ModuleNotFoundError:
    importedVisLibs = False


class Vertex():
    def __init__(self, id):
        self.id = id
        self.component = 0
        self.state = 0

    def __str__(self):
        return str(self.id)
        
    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        return self.id == other.id and self.component == other.component and self.state == other.state
        
    def __ne__(self, other):
        return not self.__eq__(other)

    def __gt__(self, other):
        if self.id > other.id:
            return True
   
    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def __lt__(self, other):
        return not self.__ge__(other)

    def __le__(self, other):
        return self.__lt__(other) or self.__eq__(other)

    def update(self, **kwargs):
        for key, value in kwargs.items():
            if key == 'component':
                self.component = value
            elif key == 'state':
                self.state = value

class Graph():
    def __init__(self, n_verts): 
        self.n_verts = n_verts
        self.adjacency_matrix = [[0 for i in range(n_verts)] for i in range(n_verts)]
        self.vertices = [Vertex(i) for i in range(n_verts)]

    def __str__(self):
        string = ""
        for i in range(self.n_verts):
            string += ", ".join([str(w) for w in self.adjacency_matrix[i]]) + "\n"
        return string
    
    def __repr__(self):
        return self.__str__()
    
    def addUpperHalfAdjacencyMatrix(self, upper_half):
        for i, line in enumerate(upper_half):
            for j, w in enumerate(line):
                self.adjacency_matrix[i][j+i+1] = w
                self.adjacency_matrix[j+i+1][i] = w
    
    def _weight(self, *edge):
        i, j = edge
        return self.adjacency_matrix[i][j]

    def weight(self, path):
        w = 0
        for i in range(len(path)-1):
            w += self._weight(path[i].id, path[i+1].id)
        return w

    def plot(self):
        if importedVisLibs == True:
            G = nx.Graph()        
            for i in range(self.n_verts):
                for j in range(self.n_verts):
                    if self._weight(i,j) > 0:
                        G.add_edge(i+1, j+1, weight=self._weight(i,j))

            pos=nx.spring_layout(G)
            nx.draw_networkx(G,pos)
            labels = nx.get_edge_attributes(G,'weight')
            nx.draw_networkx_edge_labels(G,pos,edge_labels=labels)

            plt.savefig("graph.png") 
        else:
            print(self)
            
    @staticmethod
    def getNeighborhoodFromVertice(v, graph, subgraph_vertices=None):
        neighborhood = []
        if subgraph_vertices == None:
            for n in graph.vertices:
                if graph._weight(v.id, n.id) > 0:
                    neighborhood.append(n)
        else:
            for n in subgraph_vertices:
                if graph._weight(v.id, n.id) > 0:
                    neighborhood.append(n)
        return neighborhood

    @staticmethod
    def setConnectedComponentFromRoot(r, graph, subgraph_vertices=None):
        vertices_to_check = [r]
        r.update(state=1)
        while len(vertices_to_check) != 0:
            v = vertices_to_check.pop()
            for w in Graph.getNeighborhoodFromVertice(v, graph, subgraph_vertices):
                if w.state == 0:
                    w.update(component=r.component, state=1)
                    vertices_to_check.append(w)
            v.update(state=2)            

    @staticmethod
    def setConnectedComponents(graph, subgraph_vertices=None):
        if subgraph_vertices == None:
            for v in graph.vertices:
                v.update(component=0, state=0)

            c = 0
            for v in graph.vertices:
                if v.state == 0:
                    c = c + 1
                    v.update(component=c)
                    Graph.setConnectedComponentFromRoot(v, graph)
        else:
            for v in subgraph_vertices:
                v.update(component=0, state=0)

            c = 0
            for v in subgraph_vertices:
                if v.state == 0:
                    c = c + 1
                    v.update(component=c)
                    Graph.setConnectedComponentFromRoot(v, graph, subgraph_vertices)

