#!/usr/bin/env python3
import sys
import random

print(sys.argv[1])
for i in reversed(range(int(sys.argv[1]))):
    print(' '.join([str(random.randint(0,10) if random.randint(0,1) % 2 == 0 else '0') for j in range(i)]))
